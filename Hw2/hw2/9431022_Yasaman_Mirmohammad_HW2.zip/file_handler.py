def read_from_file():
    """
    read data points from csv
    :return: array of data
    """
    return