import statistics

import matplotlib.pyplot as plt

import file_handler as fh


def plot():
    """
    Plot data points with the best vector for dimension reduction
    :return:
    """


data = fh.read_from_file('Dataset2.csv')
X = data.iloc[:, 0]
Y = data.iloc[:, 1]
Z = []
axis = []

i = 0
for x in X:
    zi = 0.01* x - 0.01 * Y[i]
    Z.append(zi)
    axis.append((zi - 0.01 * x) / -0.01)
    i += 1

Zprim = statistics.stdev(Z, statistics.mean(Z))
print(Zprim)

plt.scatter(X, Y)
plt.plot(Z)
plt.show()

"""data = fh.read_from_file('Dataset1.csv')
X = data.iloc[:, 0]
Y = data.iloc[:, 1]
a = 1
b = 2
c = []
for i in X:
    for j in Y:
        c.append(a * i + b * j)
print(c)
plt.scatter(X, Y)
plt.hold
plt.plot(c)
plt.show()

mean1 = data.mean()
mean2 = (sum(c)/len(c))

print(mean1, mean2)

"""
