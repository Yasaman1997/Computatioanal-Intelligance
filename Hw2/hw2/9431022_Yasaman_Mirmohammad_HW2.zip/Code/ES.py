import math

import Chromosome as  c

Mu = 10
# Todo change Mu's coefficient below to attain the best result
Lambda = 1 * Mu
crossover_probability = 0.4


def __init__(self, max, min, dataSet, initial_number, select_number, p_mutation, p_combination, goal_st_derivation):
    self.initial_number = initial_number
    self.select_number = select_number
    self.p_mutation = p_mutation
    self.p_combination = p_combination
    self.sigma = np.random.normal(0, 0.05)
    self.X_dim = dataSet[0]
    self.Y_dim = dataSet[1]
    self.max = max
    self.min = min
    self.initial_population_set = []
    self.select_population_set = []
    self.goal_st_derivation = goal_st_derivation


def generate_initial_population(self):
    # Todo
    list_of_chromosomes = []
    for i in range(0, self.initial_number):
        chromosome = c.Chromosome(2, self.min, self.max, self.X_dim, self.Y_dim)
        self.initial_population_set.append(chromosome)
        return list_of_chromosomes


def generate_new_seed():
    """
    :return: return lambda selected parents
    """
    # Todo
    return


'''def crossover(chromosome1, chromosome2):
    # Todo
    return
'''


def mutation(self):
    """
    Don't forget to use Gaussian Noise here !
    :param chromosome:
    :return: mutated chromosome
    """
    N01 = np.random.normal(0, 1, 2)

    for chromosome in self.select_population_set:
        chromosome.gene[2] = chromosome.gene[2] * math.exp(-np.random.normal(0, 1) * self.sigma)
        chromosome.gene[0] += N01[0] * chromosome.gene[2]
        chromosome.gene[1] += N01[1] * chromosome.gene[2]
        norm = ((chromosome.gene[0]) ** 2 + (chromosome.gene[1]) ** 2) ** 0.5
        chromosome.gene[0] /= norm
        chromosome.gene[1] /= norm
        self.sigma = np.random.normal(0, 0.05);
        chromosome.evaluate_update()


def crossover(self):
    num_crossovers = np.round(len(self.select_population_set) * self.p_combination)
    select_index_combination = np.random.randint(0, self.initial_number * 3 - 1, int(num_crossovers))
    for i in range(0, len(select_index_combination) - 1):
        # try:
        self.select_population_set[select_index_combination[i]].gene[0] = \
            statistics.mean([self.select_population_set[select_index_combination[i]].gene[0],
                             self.select_population_set[select_index_combination[i + 1]].gene[0]])
        self.select_population_set[select_index_combination[i]].evluate_update()

        self.select_population_set[select_index_combination[i + 1]].gene[1] = \
            statistics.mean([self.select_population_set[select_index_combination[i]].gene[1],
                             self.select_population_set[select_index_combination[i + 1]].gene[1]])
        self.select_population_set[select_index_combination[i + 1]].evluate_update()
        i += 1


def update_chrom_score(self):
    for index in self.select_population():
        index.evaluate_update()


def choose_parent(self):
    for i in range(1, 4):
        select_index = np.random.randint(0, self.initial_number - 1, self.initial_number)

        for index in select_index:
            self.select_population_set.append(self.initial_population_set[index])


def evaluate_new_generation():
    # Todo
    """
    Call evaluate method for each new chromosome
    :return: list of chromosomes with evaluated scores
    """
    return


def choose_new_generation(self):
    # Todo
    """
    Use one of the discussed methods in class.
    Q-tournament is suggested !
    :return: Mu selected chromosomes for next cycle
    """
    select_chrom_set = [0, 0, 0, 0]
    q_tornoment = 4

    #
    chromosome_set = self.select_population_set
    chromosome_set.extend(self.initial_population_set)
    self.initial_population_set.clear()
    for i in range(0, self.initial_number):
        select_index = np.random.randint(0, len(chromosome_set) - 1 - i, q_tornoment)
        j = 0
        for index in select_index:
            select_chrom_set[j] = chromosome_set[index]
            j += 1

        sorted(select_chrom_set, key=lambda x: x.score, reverse=False)
        self.initial_population_set.append(select_chrom_set[0])
        chromosome_set.remove(select_chrom_set[0])
        self.initial_population_set = sorted(self.initial_population_set, key=lambda x: x.score, reverse=False)

    return


def evolution_process(self):
    self.initial_population()
    i = 0
    while (i in range(0, 20)):
        for x in self.initial_population_set:
            print(x.score)

        self.select_parent()
        self.mutation()
        self.crossover()
        self.select_population()

        print("*************************************************")
        i += 1
        print("best chromosome:", self.initial_population_set[0].score,
              statistics.stdev(self.initial_population_set[0].Z, statistics.mean(self.initial_population_set[0].Z)))
        print("worst chromosome:", self.initial_population_set[self.initial_number - 1].score)
        print("mean score:", statistics.mean(chrom.score for chrom in self.initial_population_set))
        if i > 100:
            break

        return self.initial_population_set[0]


"""def isGoal(self):
    if (math.fabs(self.goal_st_derivation - self.initial_population_set[0].score) > 0.1):


def covariance_calc(X_dim, Y_dim):
    X_mean = statistics.mean(X_dim)
    Y_mean = statistics.mean(Y_dim)
    co_variance_matrix = [][2]
    co_variance_matrix[0][0] = statistics.variance(X_dim, X_mean)
    co_variance_matrix[1][1] = statistics.variance(Y_dim, Y_mean)

    i = 0
    co_variance = 0
    for index in X_dim:
        co_variance += (index - X_mean) * (Y_dim[i] - Y_mean)
    co_variance /= (len(X_dim) - 1)

    co_variance_matrix[0][1] = co_variance
    co_variance_matrix[1][0] = co_variance

    return True """""

