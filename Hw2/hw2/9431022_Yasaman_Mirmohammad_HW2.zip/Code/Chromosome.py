import statistics

import numpy as np


class Chromosome:

    def __init__(self, chromosome_length, min, max, X_dim, Y_dim):
        # Todo create a random list for genes between min and max below
        self.gene = []
        self.score = 0
        # Todo create a random list for genes between min and max below
        # Create a ,b and  for every x,y apply them to this a,b
        # every gen contain ØŸa or b valu
        # every chromosome is  (a,b) for data set that reduce dim to 1 .
        self.Z = []
        self.gene.append(np.random.normal(0, 1) * (max - min))
        self.gene.append(np.random.normal(0, 1) * (max - min))
        self.X_dim = X_dim
        self.Y_dim = Y_dim
        # self.calculate_1dim_data()
        self.evaluate()


def evaluate(self):
    """
    Update Score Field Here
    """
    # Todo
    # for evaluate method we calculate Zi for every data(Xi,Yi) then get standard derivation of Z for score of chromosome
    self.calculate_1dim_data();
    st_derivation = statistics.stdev(self.Z, statistics.mean(self.Z))
    self.score = st_derivation

def calculate_data(self):
    i = 0
    for x in self.X_dim:
        zi = self.gene[0] * x + self.gene[1] * self.Y_dim[i]
        self.Z.append(zi)
        i += 1


def evaluate(self):
    # for evaluate method we calculate Zi for every data(Xi,Yi) then get standard derivation of Z for score of chromosome
    self.calculate_1dim_data();
    st_derivation = statistics.stdev(self.Z, statistics.mean(self.Z))
    self.score = st_derivation


def evaluate_update(self):
    self.evaluate()


