import pandas as pd


def read_from_file(filename):
    """
    read data points from csv
    :return: array of data
    """
    data = pd.read_csv('Dataset1.csv')


    return data

"""  testsite_array = []
    with open(filename) as my_file:
        for line in my_file:
            testsite_array.append(line)
    return testsite_array

"""
