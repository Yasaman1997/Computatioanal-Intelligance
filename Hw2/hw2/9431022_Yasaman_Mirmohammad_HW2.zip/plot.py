def plot():
    """
    Plot data points with the best vector for dimension reduction
    :return:
    """