class Chromosome:
    def __init__(self, chromosome_length, min, max):
        # Todo create a random list for genes between min and max below
        self.gene = []
        self.score = 0

    def evaluate(self):
        """
        Update Score Field Here
        """
        #Todo
